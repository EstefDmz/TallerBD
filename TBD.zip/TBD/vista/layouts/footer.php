       <!-- /contenido-->
       </div> 

       <script src="../js/bootstrap.js"></script>

</body>
</html>