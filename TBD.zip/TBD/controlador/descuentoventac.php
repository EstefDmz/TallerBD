<?php
require_once("../modelo/index.php");
class modeloController{
    private $model;
    public function __construct(){
        $this->model = new Modelo();
    }

    // mostrar
    static function index(){
        $descuentoVenta   = new Modelo();
        $dato       =   $descuentoVenta->mostrar("descuentoventa","");
        require_once("../vista/descuentoventav.php");
    }
    
    //nuevo
    static function nuevo(){        
        require_once("../vista/descuentoventan.php");
    }

    //guardar
    static function guardar(){
        $idven = $_REQUEST['idven'];
        $iddes = $_REQUEST['iddes'];
        $idUsrc = $_SESSION['idU'];
        $data = "'$idven', '$iddes', '$idUsrc'";
        $campos = "idVenta, idDescuento, idUsuarioCrea";
        $descuentoVenta = new Modelo();
        $dato = $descuentoVenta->insertar("descuentoventa", $campos,$data);
        header("location: ../modelo/descuentoventa.php");
    }

    //editar
    static function editar(){    
        $iddescuentoVenta = $_REQUEST['idDescuentoVenta'];
        $descuentoVenta = new Modelo();
        $dato = $descuentoVenta->mostrar("descuentoventa","and idDescuentoVenta=".$iddescuentoVenta);        
        require_once("../vista/descuentoventau.php");
    }

    //actualizar
    static function actualizar(){
        $idven = $_REQUEST['idven'];
        $iddes = $_REQUEST['iddes'];
        $iddescuentoVenta = $_REQUEST['idDescuentoVenta'];
        $idUM=$_SESSION['idU'];
        $data = "idVenta='$idven', idDescuento='$iddes', idUsuarioModifica=$idUM";
        $condi = "idDescuentoVenta=$iddescuentoVenta";
        $descuentoVenta = new Modelo();
        $dato = $descuentoVenta->actualizar("descuentoventa",$data, $condi);
        header("location: ../modelo/descuentoventa.php");
    }

    //eliminar
    static function eliminar(){    
        $iddescuentoVenta = $_REQUEST['idDescuentoVenta'];
        $descuentoVenta = new Modelo();
        $dato = $descuentoVenta->eliminar("descuentoventa","idDescuentoVenta=".$iddescuentoVenta);
        header("location: ../modelo/descuentoventa.php");
    }
}
