<?php
require_once("../modelo/index.php");
class modeloController{
    private $model;
    public function __construct(){
        $this->model = new Modelo();
    }

    // mostrar
    static function index(){
        $platilloVenta   = new Modelo();
        $dato       =   $platilloVenta->mostrar("platilloventa","");
        require_once("../vista/platilloventav.php");
    }
    
    //nuevo
    static function nuevo(){        
        require_once("../vista/platilloventan.php");
    }

    //guardar
    static function guardar(){
        $idpla = $_REQUEST['idpla'];
        $idven = $_REQUEST['idven'];
        $idUsrc = $_SESSION['idU'];
        $data = "'$idpla', '$idven', '$idUsrc'";
        $campos = "idPlatillo, idVenta, idUsuarioCrea";
        $platilloVenta = new Modelo();
        $dato = $platilloVenta->insertar("platilloventa", $campos,$data);
        header("location: ../modelo/platilloventa.php");
    }

    //editar
    static function editar(){    
        $idplatilloVenta = $_REQUEST['idPlatilloVenta'];
        $platilloVenta = new Modelo();
        $dato = $platilloVenta->mostrar("platilloventa","and idPlatilloVenta=".$idplatilloVenta);        
        require_once("../vista/platilloventau.php");
    }

    //actualizar
    static function actualizar(){
        $idpla = $_REQUEST['idpla'];
        $idven = $_REQUEST['idven'];
        $idplatilloVenta = $_REQUEST['idPlatilloVenta'];
        $idUM=$_SESSION['idU'];
        $data = "idVenta='$idven', idPlatillo='$idpla', idUsuarioModifica=$idUM";
        $condi = "idPlatilloVenta=$idplatilloVenta";
        $platilloVenta = new Modelo();
        $dato = $platilloVenta->actualizar("platilloventa",$data, $condi);
        header("location: ../modelo/platilloventa.php");
    }

    //eliminar
    static function eliminar(){    
        $idplatilloVenta = $_REQUEST['idPlatilloVenta'];
        $platilloVenta = new Modelo();
        $dato = $platilloVenta->eliminar("platilloventa","idPlatilloVenta=".$idplatilloVenta);
        header("location: ../modelo/platilloventa.php");
    }
}
